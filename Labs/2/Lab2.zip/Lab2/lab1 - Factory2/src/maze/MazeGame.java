package maze;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Scanner;

import maze.ui.MazeViewer;

public class MazeGame{
	public MazeGame() {
	}
	
	public Maze createMaze(MazeFactory in_factory)
	{
		
		Maze maze = in_factory.makeMaze();
		Room r0 = in_factory.makeRoom(0);
		Room r1 = in_factory.makeRoom(1);
		Door d0_1 = in_factory.makeDoor(r0, r1);
		r0.setSide(Direction.North, in_factory.makeWall());
		r0.setSide(Direction.East , d0_1);
		r0.setSide(Direction.South, in_factory.makeWall());
		r0.setSide(Direction.West , in_factory.makeWall());
		r1.setSide(Direction.North, in_factory.makeWall());
		r1.setSide(Direction.East , in_factory.makeWall());
		r1.setSide(Direction.South, in_factory.makeWall());
		r1.setSide(Direction.West , d0_1);
		maze.addRoom(r0);
		maze.addRoom(r1);
		
		maze.setCurrentRoom(0);
		return maze;
	}
	
	public Maze loadMaze(final String path, MazeFactory in_factory){
		Maze maze = in_factory.makeMaze();
		File file = new File(path);
		Scanner fileReader = null;
		Dictionary<String, Room> rooms = new Hashtable<String, Room>();
		Dictionary<String, Door> doors = new Hashtable<String, Door>();

		
		try {
			fileReader = new Scanner(file);
		} catch (FileNotFoundException e) {
			System.out.println("Failed to find file");
			return null;
		}
		
		
		
		while(fileReader.hasNextLine()) {
			String line = fileReader.nextLine();
			String[] lineSplit = line.split("\\s+");
			
			if(lineSplit[0].compareTo("room") == 0) {
				rooms.put(lineSplit[1], in_factory.makeRoom(Integer.parseInt(lineSplit[1])));
			}else if(lineSplit[0].compareTo("door") == 0) {
				doors.put(lineSplit[1], in_factory.makeDoor(rooms.get(lineSplit[2]), rooms.get(lineSplit[3])));
				doors.get(lineSplit[1]).setOpen((lineSplit[4].compareTo("open") == 0) ? true : false);
			}		
		}
		
		fileReader.close();
		
		try {
			fileReader = new Scanner(file);
		} catch (FileNotFoundException e) {
			System.out.println("Failed to find file");
			return null;
		}

		while(fileReader.hasNextLine()) {
			String line = fileReader.nextLine();
			String[] lineSplit = line.split("\\s+");
			int i = 2;
			if(lineSplit[0].compareTo("room") == 0) {
				for(Direction dir : Direction.values()) {
					MapSite s = null;
					if(lineSplit[i].compareTo("wall") == 0) {
						s = in_factory.makeWall();
					}else if(lineSplit[i].startsWith("d")) {
						s = doors.get(lineSplit[i]);
					}else {
						s = rooms.get(lineSplit[i]);
					}
					rooms.get(lineSplit[1]).setSide(dir, s);
					i++;
				}
				maze.addRoom(rooms.get(lineSplit[1]));
			}
		}
		
		fileReader.close();
		maze.setCurrentRoom(0);
		return maze;
	}
	
	public static void main(String[] args)
	{
		MazeGame    mg = new MazeGame();
		MazeFactory mf = null;		
		Maze maze = null;
		int file = 0;
		
		if(file > 2) {
			System.out.println("Too many arguments, [color] [filename]");
			System.exit(1);
		}
		
		if(args.length == 0) {
			mf   = new MazeFactory();
			maze = mg.createMaze(mf);
		}else if(args[0].compareToIgnoreCase("red") == 0) {
			mf   = new RedMazeFactory();
			file = 1;
		}else if(args[0].compareToIgnoreCase("blue") == 0){
			mf   = new BlueMazeFactory();
			file = 1;
		}else {
			mf   = new MazeFactory();
		}
		
		if(file == 1 && args.length == 2) {
			maze = mg.loadMaze(args[1], mf);
		}else if(file == 0 && args.length == 1){
			maze = mg.loadMaze(args[0], mf);
		}else {
			maze = mg.createMaze(mf);
		}
		
		if(maze == null) {
			System.exit(2);
		}
	    MazeViewer viewer = new MazeViewer(maze);
	    viewer.run();
	}
}
