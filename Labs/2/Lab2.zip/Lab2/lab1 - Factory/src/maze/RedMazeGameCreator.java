package maze;

public class RedMazeGameCreator extends MazeGameCreator{

	public Room makeRoom(int i) {
		return new RedRoom(i);
	}
	
	public Wall makeWall() {
		return new RedWall();
	}
	
}
