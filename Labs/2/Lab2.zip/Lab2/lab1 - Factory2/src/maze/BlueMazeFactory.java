package maze;

public class BlueMazeFactory extends MazeFactory	{
	protected Door makeDoor(Room a, Room b) {
		return new BrownDoor(a, b);
	}
	
	public Room makeRoom(int i) {
		return new GreenRoom(i);
	}
	
	public Wall makeWall() {
		return new BlueWall();
	}
	
	
}
