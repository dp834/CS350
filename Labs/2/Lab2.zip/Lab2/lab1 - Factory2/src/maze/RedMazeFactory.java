package maze;

public class RedMazeFactory extends MazeFactory{

	public Room makeRoom(int i) {
		return new RedRoom(i);
	}
	
	public Wall makeWall() {
		return new RedWall();
	}
	
}
